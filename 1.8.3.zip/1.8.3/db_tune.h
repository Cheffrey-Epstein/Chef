/* This is just a stub for now; various db-layer-specific tuning functions
 * will eventually live here.
 */

extern void db_log_cache_stats(void);
extern Var db_verb_cache_stats(void);
